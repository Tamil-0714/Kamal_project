<?php
session_start();
include("dbconnect.php");
session_start();
$username=$_SESSION['username'];
extract($_REQUEST);

$mq11=mysqli_query($connect,"select * from customers where id='$id'");
$mr11=mysqli_fetch_array($mq11);
$customer_name=$mr11['customer_name'];
$customer_email=$mr11['customer_email'];
$customer_phone=$mr11['customer_phone'];
$customer_address=$mr11['customer_address'];

$rdate=date("d-m-Y");
$msg="";
if(isset($btn))
{
	 	
$uploadDir = "uploads/";
$file = $uploadDir . basename($_FILES["file"]["name"]);

if (move_uploaded_file($_FILES["file"]["tmp_name"], $file)) {
    echo "";
} else {
    echo "";
}
	$mq=mysqli_query($connect,"select max(id) from contactlens_book");
	$mr=mysqli_fetch_array($mq);
	$id=$mr['max(id)']+1;
    $fprice=$qty*$oprice;
    $ins = mysqli_query($connect, "INSERT INTO contactlens_book (id, customer_name, customer_email, customer_phone, customer_address, brand, power_category, lcolor, fvalue, tvalue, ousage, ofile, create_date, oprice, qty, fprice) 
    VALUES ('$id', '$customer_name', '$customer_email', '$customer_phone', '$customer_address', '$brand', '$power_category', '$lcolor', '$fvalue', '$tvalue', '$usage', '$file', '$rdate', '$oprice', '$qty', '$fprice')");
    
			if($ins)
			{
		 ?>
	<script language="javascript">
		alert("Contact Lens Added");
		window.location.href="createcl.php";
		 </script>
		 <?php
			}
	
	else
	{
	$msg="Already Exist!";
	}
}

include('includes/header.php');
include('includes/navbar.php');
?>

<!-- Begin Page Content -->
<div class="container-fluid">
    <h1 class="h3 mb-4 text-gray-800 text-uppercase">Contact Lens</h1>
    <span class="text-danger"><?php echo $msg;?></span>

    <div class="row">
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary text-center">Customer & Contact Lens Details</h6>
            </div>
            
            <div class="card-body">
                <form class="form-horizontal" action="" method="POST" enctype="multipart/form-data">
                    
                    <!-- Customer Details -->
                    
                    <hr>

                    <!-- Optical Details -->
                    <h5 class="text-primary">Contact Lens Details</h5>
                    <div class="form-group row">
                        <label class="control-label col-sm-2" for="brand">Brand</label>
                        <div class="col-sm-10">
                            <select class="form-control mb-2" id="brand" name="brand" required>
                                <option value="Bausch & Lomb">Bausch & Lomb</option>
                                <option value="Alcon">Alcon</option>
                                <option value="Waldo">Waldo</option>
                                <option value="Acuvue">Acuvue</option>
                                <option value="CooperVision">CooperVision</option>
                            </select>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label class="control-label col-sm-2" for="power-category">Power Category</label>
                        <div class="col-sm-10">
                            <select class="form-control mb-2" id="power-category" name="power_category" required>
                                <option value="Normal">Normal</option>
                                <option value="Power">Power</option>
                            </select>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label class="control-label col-sm-2" for="power-category">Color</label>
                        <div class="col-sm-10">
                            <select class="form-control mb-2" id="power-category" name="lcolor" required>
                                <option value="Blue">Blue</option>
                                <option value="Red">Red</option>
                                <option value="Yellow">Yellow</option>
                            </select>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label class="control-label col-sm-2" for="power-value">Power Value from</label>
                        <div class="col-sm-10">
                            <select class="form-control mb-2" id="power-value" name="fvalue">
                                <?php for ($i = -0.25; $i <= 5.00; $i += 0.25) { ?>
                                    <option value="No Power">No Power</option>
                                    <option value="<?php echo $i; ?>"><?php echo $i; ?></option>
                                <?php } ?>
                            </select>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label class="control-label col-sm-2" for="power-value">Power Value to</label>
                        <div class="col-sm-10">
                            <select class="form-control mb-2" id="power-value" name="tvalue">
                            <option value="No Power">No Power</option>

                                <?php for ($i = -0.25; $i <= 5.00; $i += 0.25) { ?>
                                    <option value="<?php echo $i; ?>"><?php echo $i; ?></option>
                                <?php } ?>
                            </select>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label class="control-label col-sm-2" for="usage">Usage Type</label>
                        <div class="col-sm-10">
                            <select class="form-control mb-2" id="usage" name="usage" required>
                                <option value="normal-life">Normal Life</option>
                                <option value="single-vision">Single Vision</option>
                                <option value="bifocal">Bifocal</option>
                                <option value="progressive">Progressive</option>
                                <option value="reading-glass">Reading Glass</option>
                                <option value="blue-light-protection">Blue Light Protection</option>
                            </select>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label class="control-label col-sm-2" for="file">Image</label>
                        <div class="col-sm-10">
                            <input type="file" class="form-control mb-2" name="file">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="control-label col-sm-2" for="file">Optical Price</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control mb-2" name="oprice">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="control-label col-sm-2" for="file">Quantity</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control mb-2" name="qty">
                        </div>
                    </div>

                    <button class="btn btn-block btn-primary" type="submit" name="btn">Submit</button>
                </form>
            </div>
        </div>
    </div>
</div>


    <?php
    include('includes/footer.php');
    include('includes/scripts.php');
    ?>