<?php
$connect=mysqli_connect("localhost","root","TooJoo_1967","optical_shop");
?>