<?php
session_start();
include("dbconnect.php");
session_start();
$username=$_SESSION['username'];
/* $q2 = mysqli_query($connect, "SELECT * FROM ar_provider where uname='$uname'");
$r1 = mysqli_fetch_array($q2) */

include('includes/header.php');
include('includes/navbar.php');
?>

<!-- Begin Page Content -->
<div class="container-fluid">
    <h1 class="h3 mb-4 text-gray-800 text-uppercase text-center">WELCOME <?php echo $username; ?>!!!</h1>


    <?php
    include('includes/footer.php');
    include('includes/scripts.php');
    ?>