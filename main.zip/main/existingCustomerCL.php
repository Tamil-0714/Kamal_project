<?php
// Connect to the database
include("dbconnect.php");

// Fetch all data from the customers table
$query = "SELECT * FROM customers";
$result = mysqli_query($connect, $query);

if (!$result) {
    die("Database query failed: " . mysqli_error($connect));
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Customer Data</title>
    <style>
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #4CAF50;
            color: white;
        }
        tr:hover {
            background-color: chocolate !important;
            cursor: pointer;
        }
        tr:nth-child(even) {
            background-color: #f2f2f2;
        }
    </style>
</head>
<body>

<h2>Customer Details</h2>
<table>
    <tr>
        <th>ID</th>
        <th>Customer Name</th>
        <th>Customer Email</th>
        <th>Customer Phone</th>
        <th>Customer Address</th>
        <th>Create Date</th>
    </tr>

    <?php while ($row = mysqli_fetch_assoc($result)) { ?>
        <tr onclick="makethisposible(<?php echo htmlspecialchars($row['id']); ?>)">
            <td><?php echo htmlspecialchars($row['id']); ?></td>
            <td><?php echo htmlspecialchars($row['customer_name']); ?></td>
            <td><?php echo htmlspecialchars($row['customer_email']); ?></td>
            <td><?php echo htmlspecialchars($row['customer_phone']); ?></td>
            <td><?php echo htmlspecialchars($row['customer_address']); ?></td>
            <td><?php echo htmlspecialchars($row['create_date']); ?></td>
        </tr>
    <?php } ?>
</table>

</body>

<script>
    function makethisposible(id) {
        window.location.href = `contactlensbook.php?id=${id}`
    }
</script>
</html>

<?php
// Close database connection
mysqli_close($connect);
?>
