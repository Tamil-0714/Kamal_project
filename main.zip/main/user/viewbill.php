<?php
session_start();
include("dbconnect.php");
$username=$_SESSION['username'];

if (isset($_GET['id'])) {
    $bookid = $_GET['id'];
    
    // Fetch order details
    $query ="SELECT b.*, o.* , b.id AS bookid 
    FROM booking b
    LEFT JOIN opticals o ON b.bid = o.id
    WHERE b.id = '$bookid'"
    ;
    
    
    $result = mysqli_query($connect, $query);
    $order = mysqli_fetch_assoc($result);
    $q1=mysqli_query($connect,"select * from user where username='".$order['user']."'");
    $r11=mysqli_fetch_array($q1);
    $mobile=$r11['mobile'];
    
    if (!$order) {
        echo "Bill not found!";
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order Bill</title>
    <style>
        body { font-family: Arial, sans-serif; }
        .bill-container { width: 60%; margin: auto; padding: 20px; border: 1px solid #000; }
        h2, h3 { text-align: center; }
        table { width: 100%; border-collapse: collapse; margin-top: 10px; }
        th, td { border: 1px solid black; padding: 8px; text-align: center; }
    </style>
</head>
<body>

<div class="bill-container">
<!--     <h2>SURYA OPTICALS</h2>
 -->    <h2>ORDER BILL</h2>
    
    <p><strong>Order No:</strong> <?php echo $order['bookid']; ?></p>
    <p><strong>Customer Name:</strong> <?php echo $order['user']; ?></p>
    <p><strong>Mobile:</strong> <?php echo  $mobile; ?></p>
    <p><strong>Order Date:</strong> <?php echo $order['rdate']; ?></p>
    
    <table>
        <tr>
            <th>SNO</th>
            <th>Product</th>
            <th>HSN</th>
            <th>QTY</th>
            <th>Amount</th>
        </tr>

<?php
            echo "<tr>
                    <td>1</td>
                    <td>{$order['brand']}</td>
                    <td>9001</td>
                    <td>{$order['qty']}</td>
                    <td>{$order['oprice']}</td>
                  </tr>";
       
    
        ?>

    </table>

    <h3>Total Amount: ?.<?php echo number_format($order['tprice'], 2); ?></h3>

</div>

</body>
</html>
