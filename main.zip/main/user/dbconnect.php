<?php
$connect=mysqli_connect("localhost","root","","optical_shop");
?>