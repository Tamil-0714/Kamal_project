<?php
include("dbconnect.php");
session_start();
$username=$_SESSION['username'];
/* $q2 = mysqli_query($connect, "SELECT * FROM ar_provider where uname='$uname'");
$r1 = mysqli_fetch_array($q2) */
?>
<!DOCTYPE html>
<html>

<head>
    <title>
        HOMEPAGE
    </title>
    <!-- <link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" /> -->
    <?php
    include 'links.php'
    ?>
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="js/jquery.min.js"></script>
    <!-- Custom Theme files -->
    <link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
    <!-- Custom Theme files -->
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <script type="application/x-javascript">
        addEventListener("load", function() {
            setTimeout(hideURLbar, 0);
        }, false);

        function hideURLbar() {
            window.scrollTo(0, 1);
        }
    </script>
    <meta name="keywords" content="Tender Responsive web template, Bootstrap Web Templates, Flat Web Templates, AndriodCompatible web template, Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyErricsson, Motorola web design" />
    <!--Google Fonts-->
    <link href="http://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800" rel="stylesheet" type="text/css" />
    <!-- start-smoth-scrolling -->
    <script type="text/javascript" src="js/move-top.js"></script>
    <script type="text/javascript" src="js/easing.js"></script>
    <script type="text/javascript">
        jQuery(document).ready(function($) {
            $(".scroll").click(function(event) {
                event.preventDefault();
                $("html,body").animate({
                        scrollTop: $(this.hash).offset().top
                    },
                    1000
                );
            });
        });
    </script>
    <!-- //end-smoth-scrolling -->
</head>

<body>
    <!--top nav start here-->
    <div class="mother-grid">
        <div class="container">
            <div class="temp-padd">
                <!--top nav end here-->
                <!--title start here-->
                <div class="title-main">
                    <a href="index.html">
                    <h1><?php include("title.php");?></h1>
                    </a>
                </div>
                <!--title end here-->
                <!--header start here-->
                <div class="header mb-4">
                    <div class="navg">
                        <span class="menu"> <img src="images/icon.png" alt="" /></span>
                        <ul class="res">
                            <li><a href="index.php">Home</a></li>
                            <li><a href="opticals.php">Opticals</a></li>
                            <li><a href="myBiddings.php">My Booking</a></li>
                            <li><a href="includes/logout.inc.php">Logout</a></li>
                            
                            </ul>
                        <script>
                            $("span.menu").click(function() {
                                $("ul.res").slideToggle("slow", function() {
                                    // Animation complete.
                                });
                            });
                        </script>
                    </div>
                    <form class="search" action="search.php" method="GET">
                        <!-- <div class="search"> -->
                        <input type="text" name="query" value="search" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Site search';}" />
                        <input type="submit" value="" />
                        <!-- </div> -->
                    </form>

                    <div class="clearfix"></div>
                </div>
                <!--header end here-->

                <h4 class="heading-4 text-center mb-4 text-white bg-danger">Opticals</h4>
                <div class="card-body">
            <div class="table-responsive">
                <div id="dataTable_wrapper" class="dataTables_wrapper dt-bootstrap4">
                    <?php

                    $sql = "SELECT * FROM opticals";
                    $query = mysqli_query($connect, $sql);
                    ?>
                    <div class="row">
                        <div class="col-sm-12">
                            <table class="table table-bordered dataTable" id="dataTable" width="100%" cellspacing="0" role="grid" aria-describedby="dataTable_info">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Optical Brand</th>
                                        <th>Power Category</th>
                                        <th>Power Value</th>
                                        <th>Usage</th>
                                        <th>Image</th>
                                        <th>Created date</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    if (mysqli_num_rows($query) > 0) {
                                        $i=0;
                                        while ($row = mysqli_fetch_assoc($query)) {
                                            $i++
                                            ?>
                                            <tr id="table_row">
                                                <td><?php echo $i;?></td>
                                                <td><?php echo $row['brand'] ?></td>
                                                <td><?php echo $row['power_category'] ?></td>
                                                <td><?php echo $row['fvalue']."-".$row['tvalue'] ?></td>
                                                
                                                <td><?php echo $row['ousage'] ?></td>
                                                <td><a href="<?php echo $row['ofile'] ?>" target="_blank"><img src="../admin/<?php echo $row['ofile'] ?>" alt="" width="70" height="70"></a><?php echo $row['DueDate'] ?></td>
                                                <td><?php echo $row['create_date'] ?></td>
                                                <td><a href="book.php?id=<?php echo $row['id'];?>">Book</a></td>

                                            </tr>
                                    <?php
                                        }
                                    }
                                    ?>

                                </tbody>
                            </table>
                        </div>
                    </div>


                </div>
                <div class="my-2"></div>
            </div>
        </div>
                
    </div>
</body>

</html>