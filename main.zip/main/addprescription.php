<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Optical Prescription Form</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
        }
        .prescription-container {
            max-width: 700px;
            margin: auto;
            padding: 20px;
            border: 1px solid #ddd;
            box-shadow: 2px 2px 10px rgba(0, 0, 0, 0.1);
            border-radius: 10px;
        }
        .print-btn {
            margin-top: 20px;
            text-align: center;
        }
        @media print {
            .print-btn {
                display: none;
            }
            input, textarea {
                border: none;
                outline: none;
            }
        }
    </style>
</head>
<body>

    <div class="prescription-container">
        <h2 class="text-center">Optical Prescription</h2>
        
        <form id="prescriptionForm">
            <div class="form-group">
                <label><strong>Patient Name:</strong></label>
                <input type="text" class="form-control" id="patientName" required>
            </div>
            <div class="form-group">
                <label><strong>Date:</strong></label>
                <input type="date" class="form-control" id="date" required>
            </div>

            <table class="table">
                <thead>
                    <tr>
                        <th>Eye</th>
                        <th>SPH</th>
                        <th>CYL</th>
                        <th>AXIS</th>
                        <th>ADD</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td><strong>Right Eye (RE)</strong></td>
                        <td><input type="text" class="form-control" id="reSPH"></td>
                        <td><input type="text" class="form-control" id="reCYL"></td>
                        <td><input type="text" class="form-control" id="reAXIS"></td>
                        <td><input type="text" class="form-control" id="reADD"></td>
                    </tr>
                    <tr>
                        <td><strong>Left Eye (LE)</strong></td>
                        <td><input type="text" class="form-control" id="leSPH"></td>
                        <td><input type="text" class="form-control" id="leCYL"></td>
                        <td><input type="text" class="form-control" id="leAXIS"></td>
                        <td><input type="text" class="form-control" id="leADD"></td>
                    </tr>
                </tbody>
            </table>

            <div class="form-group">
                <label><strong>Additional Notes:</strong></label>
                <textarea class="form-control" id="notes" rows="3"></textarea>
            </div>

            <div class="print-btn">
                <button type="button" class="btn btn-success" onclick="printPrescription()">Print Prescription</button>
            </div>
        </form>
    </div>

    <script>
        function printPrescription() {
            window.print();
        }
    </script>

</body>
</html>
