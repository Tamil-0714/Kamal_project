<?php
session_start();
include("dbconnect.php");
session_start();
$username=$_SESSION['username'];
extract($_REQUEST);

include('includes/header.php');
include('includes/navbar.php');
?>

<!-- Begin Page Content -->
<div class="container-fluid">
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">View Bookings</h6>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <div id="dataTable_wrapper" class="dataTables_wrapper dt-bootstrap4">
                <?php
                $query = mysqli_query($connect, "SELECT b.*, o.* , b.id AS bookid 
                FROM booking b
                LEFT JOIN opticals o ON b.bid = o.id
               
                ;
                
                    ");

               
                ?>
                <span class="text-danger"><?php echo $msg;?></span>
                <div class="row">
                        <div class="col-sm-12">
                            <table class="table table-bordered dataTable" id="dataTable" width="100%" cellspacing="0" role="grid" aria-describedby="dataTable_info">
                                <thead>
                                    <tr>
                                    <th>#</th>
                                <th>brand</th>
                                <th>power_category</th>
                                <th>Power Value</th>
                                <th>oprice</th>
                                <th>qty</th>
                                <th>tprice</th>
                                <th>rdate</th>
                                <th>status</th>
                                <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                <?php
                            if (mysqli_num_rows($query) > 0) {
                                $i==0;
                                while ($row = mysqli_fetch_assoc($query)) {
                                    $i++
                                    ?>
                                            <tr id="table_row">
                                            <td><?php echo $i;?></td>
                                        <td><?php echo $row['brand'] ?></td>
                                        <td><?php echo $row['power_category'] ?></td>
                                        <td><?php echo $row['fvalue']."-".$row['tvalue'] ?></td>
                                        <td><?php echo $row['oprice'] ?></td>
                                        <td><?php echo $row['qty'] ?></td>
                                        <td><?php echo $row['tprice'] ?></td>
                                        <td><?php echo $row['rdate'] ?></td>
                                        <td>
                                            <?php 
                                            if($row['status']==0){
                                                echo "Booking Not Confirmed";
                                            }
                                            else if($row['status']==1){
                                                echo "Payment Success";
                                            }
                                            else{
                                                echo "Optical Delivered";
                                            }
                                            ?>
                                        </td>
                                        <td>
                                        <?php 
                                            if($row['status']==1){
                                                echo "<a href='viewBiddings.php?act=deliver&id=" . $row['bookid'] . "'>Deliver</a>";
                                            }
                                            else if($row['status']==2){
                                                echo "<a href='viewbill.php?id=" . $row['bookid'] . "' target='_blank'>View Bill</a>";
                                                
                                            }
                                            else{
                                               
                                            }
                                            ?>
                                        </td>

                                            </tr>
                                    <?php
                                        }
                                    }
                                    ?>

                                </tbody>
                            </table>
                        </div>
                    </div>
<?php
if (isset($act) && $act == "deliver") {
    
    $ins = mysqli_query($connect, "UPDATE booking SET status='2' WHERE id='$id'");
    
			if($ins)
			{
		 ?>
	<script language="javascript">
		alert("Optical Delivered");
		window.location.href="viewBiddings.php";
		 </script>
		 <?php
			}
	
	else
	{
	$msg="Error!";
	}
}
?> 

                </div>
                <div class="my-2"></div>
            </div>
        </div>
    </div>


    <?php
    include('includes/footer.php');
    include('includes/scripts.php');
    ?>