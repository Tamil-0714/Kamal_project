<?php
session_start();
include("dbconnect.php");
$username = $_SESSION['username'];

if (isset($_GET['id'])) {
    $bookid = $_GET['id'];

    // Fetch order details
    $query = "SELECT * FROM opticals_book WHERE id = '$bookid'";
    $result = mysqli_query($connect, $query);
    $order = mysqli_fetch_assoc($result);

    if (!$order) {
        echo "Bill not found!";
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order Bill</title>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js"></script>
    <!-- Add JsBarcode library -->
    <script src="https://cdn.jsdelivr.net/npm/jsbarcode@3.11.5/dist/JsBarcode.all.min.js"></script>

    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
        }

        .bill-container {
            width: 70%;
            margin: auto;
            padding: 20px;
            border: 2px solid #000;
            background: #fff;
        }

        h2, h3 {
            text-align: center;
            margin: 5px 0;
        }

        .text-right {
            text-align: right;
        }

        .text-center {
            text-align: center;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 10px;
        }

        th, td {
            border: 1px solid black;
            padding: 8px;
            text-align: center;
        }

        .barcode-img {
            width: 100px; /* Adjust the width as needed */
            height: auto;
        }

        .footer {
            text-align: center;
            font-weight: bold;
            margin-top: 20px;
        }

        .btn-container {
            text-align: center;
            margin-top: 20px;
        }

        .btn {
            padding: 10px 15px;
            font-size: 14px;
            margin: 5px;
            cursor: pointer;
            border: none;
            background: #007bff;
            color: #fff;
            border-radius: 5px;
        }

        .btn:hover {
            background: #0056b3;
        }

        @media print {
            .btn-container {
                display: none;
            }
        }
    </style>
</head>
<body>

<div class="bill-container" id="billContent">
    <h2>SURYA OPTICALS</h2>
    <p class="text-center">Trichy Road, Manaparai-621 306<br>Ph: 04332 262914 &nbsp; Cell: 99421 93914</p>
    <h3 style="text-decoration: underline;">ORDER FORM</h3>

    <div id="qrcode" class="text-center"></div>

    <p><strong>Order No:</strong> <?php echo $order['id']; ?></p>
    <p><strong>Customer Name:</strong> <?php echo $order['customer_name']; ?></p>
    <p><strong>Customer ID:</strong> <?php echo $order['id']; ?></p>
    <p><strong>Mobile:</strong> <?php echo $order['customer_phone']; ?></p>

    <table>
        <tr>
            <th>SNO</th>
            <th>Product</th>
            <th>BarCode</th>
            <th>QTY</th>
            <th>Amount</th>
        </tr>

        <?php
        $sno = 1;
        echo "<tr>
                <td>{$sno}</td>
                <td>{$order['brand']}</td>
                <td><canvas id='barcode-{$order['stock_id']}' class='barcode-img'></canvas> {$order['stock_id']}</td>
                <td>{$order['qty']}</td>
                <td>{$order['oprice']}</td>
              </tr>";
        $sno++;
        ?>
    </table>

    <p class="text-right"><strong>Total Amount:</strong> ₹ <?php echo number_format($order['fprice'], 2); ?></p>
    <h3 class="text-right">Net Amount: ₹ <?php echo number_format($order['fprice'], 2); ?></h3>

    <p><strong>Advance Paid:</strong> ₹ <?php echo number_format($order['fprice'], 2); ?></p>
    <p><strong>Balance:</strong> ₹ 0</p>

    <p><strong>Delivery Date:</strong> <?php echo date("d-m-Y"); ?></p>

    <p class="footer">
        Surya Opticals<br>
        560/1, Surya Opticals Building, Near Mariamman Kovil,<br>
        Trichy Road, Manaparai-621306<br>
        Cell: 9942193914, Ph: 04332262914
    </p>
</div>

<div class="btn-container">
    <button class="btn" onclick="printBill()">Print Bill</button>
</div>

<script>
    function printBill() {
        window.print();
    }

    function exportPDF() {
        const { jsPDF } = window.jspdf;
        let doc = new jsPDF();

        let content = document.getElementById("billContent");

        html2canvas(content, { scale: 2 }).then((canvas) => {
            let imgData = canvas.toDataURL("image/png");
            let imgWidth = 210;
            let pageHeight = 297;
            let imgHeight = (canvas.height * imgWidth) / canvas.width;

            doc.addImage(imgData, "PNG", 10, 10, imgWidth - 20, imgHeight);
            doc.save("Order_Bill.pdf");
        });
    }

    document.addEventListener("DOMContentLoaded", function () {
        // QR Code generation
        var orderData = {
            order_no: "<?php echo $order['id']; ?>",
            customer_id: "<?php echo $order['id']; ?>",
            customer_name: "<?php echo $order['customer_name']; ?>"
        };
        var qrCodeData = JSON.stringify(orderData);
        new QRCode(document.getElementById("qrcode"), {
            text: qrCodeData,
            width: 150,
            height: 150
        });

        // Barcode generation
        JsBarcode("#barcode-<?php echo $order['stock_id']; ?>", "<?php echo $order['stock_id']; ?>", {
            format: "CODE128", // You can change the format (e.g., "EAN13", "UPC", etc.) if needed
            width: 2,
            height: 40,
            displayValue: false // Set to true if you want the stock_id text below the barcode
        });
    });
</script>

</body>
</html>