<?php
session_start();
include("dbconnect.php");
session_start();
$username=$_SESSION['username'];
extract($_REQUEST);

include('includes/header.php');
include('includes/navbar.php');
?>

<!-- Begin Page Content -->
<div class="container-fluid">
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">View Opticals</h6>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <div id="dataTable_wrapper" class="dataTables_wrapper dt-bootstrap4">
                    <?php

                    $sql = "SELECT * FROM opticals_book";
                    $query = mysqli_query($connect, $sql);
                    ?>
                    <div class="row">
                        <div class="col-sm-12">
                            <table class="table table-bordered dataTable" id="dataTable" width="100%" cellspacing="0" role="grid" aria-describedby="dataTable_info">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Customer</th>
                                        <th>Mobile</th>
                                        <th>Email</th>
                                        <th>Address</th>
                                        <th>Optical Brand</th>
                                        <th>Power Category</th>
                                        <th>Power Value</th>
                                        <th>Usage</th>
                                        <th>Image</th>
                                        <th>Purchase date</th>
                                        <th>Quantity</th>
                                        <th>Price</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    if (mysqli_num_rows($query) > 0) {
                                        $i=0;
                                        while ($row = mysqli_fetch_assoc($query)) {
                                            $i++
                                            ?>
                                            <tr id="table_row">
                                                <td><?php echo $i;?></td>
                                                <td><?php echo $row['customer_name'] ?></td>
                                                <td><?php echo $row['customer_phone'] ?></td>

                                                <td><?php echo $row['customer_email'] ?></td>
                                                <td><?php echo $row['customer_address'] ?></td>
                                                
                                                <td><?php echo $row['brand'] ?></td>
                                                <td><?php echo $row['power_category'] ?></td>
                                                <td><?php echo $row['fvalue']."-".$row['tvalue'] ?></td>
                                                
                                                <td><?php echo $row['ousage'] ?></td>
                                                <td><a href="<?php echo $row['ofile'] ?>" target="_blank"><img src="<?php echo $row['ofile'] ?>" alt="" width="70" height="70"></a><?php echo $row['DueDate'] ?></td>
                                                <td><?php echo $row['create_date'] ?></td>
                                                <td><?php echo $row['qty'] ?></td>
                                                <td><?php echo $row['fprice'] ?></td>
                                                <td><?php echo "<a href='viewbill.php?id=" . $row['id'] . "' target='_blank'>View Bill</a>";?>
                                                </td>

                                            </tr>
                                    <?php
                                        }
                                    }
                                    ?>

                                </tbody>
                            </table>
                        </div>
                    </div>


                </div>
                <div class="my-2"></div>
            </div>
        </div>
    </div>


    <?php
    include('includes/footer.php');
    include('includes/scripts.php');
    ?>