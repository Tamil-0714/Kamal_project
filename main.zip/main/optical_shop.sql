-- phpMyAdmin SQL Dump
-- version 2.11.6
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Feb 18, 2025 at 07:18 AM
-- Server version: 5.0.51
-- PHP Version: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `optical_shop`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `username` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`username`, `password`) VALUES
('admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `booking`
--

CREATE TABLE `booking` (
  `id` int(11) NOT NULL,
  `bid` varchar(40) NOT NULL,
  `user` varchar(40) NOT NULL,
  `qty` varchar(40) NOT NULL,
  `oprice` varchar(40) NOT NULL,
  `tprice` varchar(100) NOT NULL,
  `status` varchar(40) NOT NULL,
  `rdate` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `booking`
--

INSERT INTO `booking` (`id`, `bid`, `user`, `qty`, `oprice`, `tprice`, `status`, `rdate`) VALUES
(1, '1', 'jebin', '2', '1000', '2000', '2', '01-02-2025');

-- --------------------------------------------------------

--
-- Table structure for table `contactlens_book`
--

CREATE TABLE `contactlens_book` (
  `id` int(11) NOT NULL,
  `customer_name` varchar(60) NOT NULL,
  `customer_email` varchar(60) NOT NULL,
  `customer_phone` varchar(60) NOT NULL,
  `customer_address` varchar(120) NOT NULL,
  `brand` varchar(60) NOT NULL,
  `power_category` varchar(60) NOT NULL,
  `lcolor` varchar(60) NOT NULL,
  `fvalue` varchar(60) NOT NULL,
  `tvalue` varchar(60) NOT NULL,
  `ousage` varchar(60) NOT NULL,
  `ofile` varchar(60) NOT NULL,
  `create_date` varchar(60) NOT NULL,
  `oprice` varchar(60) NOT NULL,
  `qty` varchar(60) NOT NULL,
  `fprice` varchar(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `contactlens_book`
--

INSERT INTO `contactlens_book` (`id`, `customer_name`, `customer_email`, `customer_phone`, `customer_address`, `brand`, `power_category`, `lcolor`, `fvalue`, `tvalue`, `ousage`, `ofile`, `create_date`, `oprice`, `qty`, `fprice`) VALUES
(1, 'selva', 'jebinp08@gmail.com', '09894918800', 'trichy', 'Alcon', 'Normal', 'Blue', 'No Power', 'No Power', 'normal-life', 'uploads/OIP.jpeg', '18-02-2025', '1000', '1', '1000'),
(2, 'gg', 'konsia2002@gmail.com', '08056705320', 'trichy\r\ntrichy', 'Waldo', 'Power', 'Red', '0.75', '1.75', 'bifocal', 'uploads/OIP.jpeg', '18-02-2025', '1000', '1', '1000');

-- --------------------------------------------------------

--
-- Table structure for table `coolers_book`
--

CREATE TABLE `coolers_book` (
  `id` int(11) NOT NULL,
  `customer_name` varchar(60) NOT NULL,
  `customer_email` varchar(60) NOT NULL,
  `customer_phone` varchar(60) NOT NULL,
  `customer_address` varchar(60) NOT NULL,
  `brand` varchar(60) NOT NULL,
  `ousage` varchar(60) NOT NULL,
  `ofile` varchar(60) NOT NULL,
  `create_date` varchar(60) NOT NULL,
  `oprice` varchar(60) NOT NULL,
  `qty` varchar(60) NOT NULL,
  `fprice` varchar(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `coolers_book`
--

INSERT INTO `coolers_book` (`id`, `customer_name`, `customer_email`, `customer_phone`, `customer_address`, `brand`, `ousage`, `ofile`, `create_date`, `oprice`, `qty`, `fprice`) VALUES
(1, 'jebin', 'jebinp08@gmail.com', '09894918800', 'trichy\r\ntrichy', 'Ray-Ban', 'reading-glass', 'uploads/OIP.jpeg', '18-02-2025', '1000', '1', '1000');

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `id` int(11) NOT NULL,
  `customer_name` varchar(60) NOT NULL,
  `customer_email` varchar(60) NOT NULL,
  `customer_phone` varchar(60) NOT NULL,
  `customer_address` varchar(60) NOT NULL,
  `create_date` varchar(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`id`, `customer_name`, `customer_email`, `customer_phone`, `customer_address`, `create_date`) VALUES
(1, 'jebin', 'konsia2002@gmail.com', '09894918800', '1234', '17-02-2025 16:40:54'),
(2, 'jebin', '', '09894918800', '11', '17-02-2025 16:42:28'),
(3, 'kuna', '', '09894918800', '11', '17-02-2025 16:42:52'),
(4, 'kuna', 'jebinp08@gmail.com', '09894918800', 'trichy', '17-02-2025 21:04:04'),
(5, 'selva', 'jebinp08@gmail.com', '09894918800', 'trichy', '18-02-2025 09:48:41'),
(6, 'selva', 'jebinp08@gmail.com', '09894918800', 'trichy', '18-02-2025 11:54:14'),
(7, 'jebin', 'jebinp08@gmail.com', '09894918800', 'trichy\r\ntrichy', '18-02-2025 12:01:54'),
(8, 'jebin', 'jebinp08@gmail.com', '09894918800', 'trichy\r\ntrichy', '18-02-2025 12:01:54'),
(9, 'kamal', 'jebinp08@gmail.com', '09894918800', 'trichy\r\ntrichy', '18-02-2025 12:07:57'),
(10, 'gg', 'konsia2002@gmail.com', '08056705320', 'trichy\r\ntrichy', '18-02-2025 12:09:13'),
(11, 'jegan', 'konsia2002@gmail.com', '08056705320', 'trichy\r\ntrichy', '18-02-2025 12:10:29');

-- --------------------------------------------------------

--
-- Table structure for table `opticals`
--

CREATE TABLE `opticals` (
  `id` int(11) NOT NULL,
  `brand` varchar(40) NOT NULL,
  `power_category` varchar(40) NOT NULL,
  `fvalue` varchar(40) NOT NULL,
  `tvalue` varchar(100) NOT NULL,
  `ousage` varchar(40) NOT NULL,
  `ofile` varchar(200) NOT NULL,
  `create_date` varchar(40) NOT NULL,
  `oprice` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `opticals`
--

INSERT INTO `opticals` (`id`, `brand`, `power_category`, `fvalue`, `tvalue`, `ousage`, `ofile`, `create_date`, `oprice`) VALUES
(1, 'Ray-Ban', 'spherical', '-0.25', '2.25', 'normal-life', 'uploads/OIP.jpeg', '01-02-2025', '1000');

-- --------------------------------------------------------

--
-- Table structure for table `opticals_book`
--

CREATE TABLE `opticals_book` (
  `id` int(11) NOT NULL,
  `customer_name` varchar(60) NOT NULL,
  `customer_email` varchar(60) NOT NULL,
  `customer_phone` varchar(60) NOT NULL,
  `customer_address` varchar(200) NOT NULL,
  `brand` varchar(60) NOT NULL,
  `power_category` varchar(60) NOT NULL,
  `fvalue` varchar(60) NOT NULL,
  `tvalue` varchar(60) NOT NULL,
  `ousage` varchar(60) NOT NULL,
  `ofile` varchar(60) NOT NULL,
  `create_date` varchar(60) NOT NULL,
  `oprice` varchar(60) NOT NULL,
  `qty` varchar(60) NOT NULL,
  `fprice` varchar(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `opticals_book`
--

INSERT INTO `opticals_book` (`id`, `customer_name`, `customer_email`, `customer_phone`, `customer_address`, `brand`, `power_category`, `fvalue`, `tvalue`, `ousage`, `ofile`, `create_date`, `oprice`, `qty`, `fprice`) VALUES
(1, 'R.Jeyavarshini', 'varshinijeya44@gmail.com', '9344562168', 'trichy', 'Ray-Ban', 'spherical', '-0.25', '-0.25', 'normal-life', 'uploads/OIP.jpeg', '07-02-2025', '1000', '2', '2000'),
(2, 'kuna', 'jebinp08@gmail.com', '09894918800', 'trichy', 'Oakley', 'spherical', '0.5', '0.25', 'normal-life', 'uploads/OIP.jpeg', '17-02-2025', '1000', '1', '1000'),
(3, 'kamal', 'jebinp08@gmail.com', '09894918800', 'trichy\r\ntrichy', 'Persol', 'cylinder', '0.25', '0.75', 'normal-life', 'uploads/OIP.jpeg', '18-02-2025', '1000', '1', '1000');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `name` varchar(40) NOT NULL,
  `mobile` varchar(40) NOT NULL,
  `email` varchar(40) NOT NULL,
  `address` varchar(100) NOT NULL,
  `username` varchar(40) NOT NULL,
  `password` varchar(40) NOT NULL,
  `create_date` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `name`, `mobile`, `email`, `address`, `username`, `password`, `create_date`) VALUES
(1, 'Jebin Prakash', '08056705320', 'konsia2002@gmail.com', 'trichy', 'jebin', 'jebin', '01-02-2025');
