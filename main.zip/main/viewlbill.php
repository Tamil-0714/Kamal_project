<?php
session_start();
include("dbconnect.php");
$username = $_SESSION['username'];

if (isset($_GET['id'])) {
    $bookid = $_GET['id'];

    // Fetch order details
    $query = "SELECT * FROM contactlens_book WHERE id = '$bookid'";
    $result = mysqli_query($connect, $query);
    $order = mysqli_fetch_assoc($result);

    if (!$order) {
        echo "Bill not found!";
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order Bill</title>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js"></script>

    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
        }

        .bill-container {
            width: 70%;
            margin: auto;
            padding: 20px;
            border: 2px solid #000;
            background: #fff; /* Ensure background is white */
        }

        h2, h3 {
            text-align: center;
            margin: 5px 0;
        }

        .text-right {
            text-align: right;
        }

        .text-center {
            text-align: center;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 10px;
        }

        th, td {
            border: 1px solid black;
            padding: 8px;
            text-align: center;
        }

        .footer {
            text-align: center;
            font-weight: bold;
            margin-top: 20px;
        }

        .btn-container {
            text-align: center;
            margin-top: 20px;
        }

        .btn {
            padding: 10px 15px;
            font-size: 14px;
            margin: 5px;
            cursor: pointer;
            border: none;
            background: #007bff;
            color: #fff;
            border-radius: 5px;
        }

        .btn:hover {
            background: #0056b3;
        }

        /* Hide buttons when printing */
        @media print {
            .btn-container {
                display: none;
            }
        }
    </style>
</head>
<body>

<div class="bill-container" id="billContent">
    <h2>SURYA OPTICALS</h2>
    <p class="text-center">Trichy Road, Manaparai-621 306<br>Ph: 04332 262914 &nbsp;&nbsp; Cell: 99421 93914</p>
    <h3 style="text-decoration: underline;">ORDER FORM</h3>
    
    <p><strong>Order No:</strong> <?php echo $order['id']; ?></p>
    <p><strong>Customer Name:</strong> <?php echo $order['customer_name']; ?></p>
    <p><strong>Customer ID:</strong> <?php echo $order['id']; ?></p>
    <p><strong>Mobile:</strong> <?php echo $order['customer_phone']; ?></p>

    <table>
        <tr>
            <th>SNO</th>
            <th>Product</th>
            <th>HSN</th>
            <th>QTY</th>
            <th>Amount</th>
        </tr>

        <?php
        $sno = 1;
        echo "<tr>
                <td>{$sno}</td>
                <td>{$order['brand']}</td>
                <td>9001</td>
                <td>{$order['qty']}</td>
                <td>{$order['oprice']}</td>
              </tr>";
        $sno++;
        ?>
    </table>

    <p class="text-right"><strong>Total Amount:</strong> &#8377; <?php echo number_format($order['fprice'], 2); ?></p>
<!--     <p class="text-right"><strong>Discount:</strong> &#8377; 7.14</p>
 -->    <h3 class="text-right">Net Amount: &#8377; <?php echo number_format($order['fprice'], 2); ?></h3>

    <p><strong>Advance Paid:</strong> &#8377; <?php echo number_format($order['fprice'], 2); ?></p>
    <p><strong>Balance:</strong> &#8377; 0</p>

    <p><strong>Delivery Date:</strong> <?php echo date("d-m-Y"); ?></p>

    <p class="footer">
        Surya Opticals<br>
        560/1, Surya Opticals Building, Near Mariamman Kovil,<br>
        Trichy Road, Manaparai-621306<br>
        Cell: 9942193914, Ph: 04332262914
    </p>
</div>

<!-- Buttons for Print & PDF Export -->
<div class="btn-container">
    <button class="btn" onclick="printBill()"> Print Bill</button>
<!--     <button class="btn" onclick="exportPDF()">?? Export as PDF</button>
 --></div>

<script>
    function printBill() {
        window.print();
    }

    function exportPDF() {
        const { jsPDF } = window.jspdf;
        let doc = new jsPDF();

        let content = document.getElementById("billContent");

        html2canvas(content, { scale: 2 }).then((canvas) => {
            let imgData = canvas.toDataURL("image/png");
            let imgWidth = 210; // A4 width in mm
            let pageHeight = 297; // A4 height in mm
            let imgHeight = (canvas.height * imgWidth) / canvas.width;

            doc.addImage(imgData, "PNG", 10, 10, imgWidth - 20, imgHeight);
            doc.save("Order_Bill.pdf");
        });
    }
</script>

</body>
</html>
