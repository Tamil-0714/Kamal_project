<?php
session_start();
include("dbconnect.php");
session_start();
$username=$_SESSION['username'];
extract($_REQUEST);
date_default_timezone_set('Asia/Kolkata');
$rdate = date("d-m-Y H:i:s");
$msg="";
if(isset($btn))
{
	 	
/* $uploadDir = "uploads/";
$file = $uploadDir . basename($_FILES["file"]["name"]);

if (move_uploaded_file($_FILES["file"]["tmp_name"], $file)) {
    echo "";
} else {
    echo "";
} */
	$mq=mysqli_query($connect,"select max(id) from customers");
	$mr=mysqli_fetch_array($mq);
	$id=$mr['max(id)']+1;
    $fprice=$qty*$oprice;
    $ins = mysqli_query($connect, "INSERT INTO customers (id, customer_name, customer_email, customer_phone, customer_address, create_date) 
    VALUES ('$id', '$customer_name', '$customer_email', '$customer_phone', '$customer_address', '$rdate')");
    
			if($ins)
			{
		 ?>
	<script language="javascript">
		alert("Customer Added");
		window.location.href="newcustomer.php";
		 </script>
		 <?php
			}
	
	else
	{
	$msg="Already Exist!";
	}
}

include('includes/header.php');
include('includes/navbar.php');
?>

<!-- Begin Page Content -->
<div class="container-fluid">
    <h1 class="h3 mb-4 text-gray-800 text-uppercase">New Customer Entry</h1>
    <span class="text-danger"><?php echo $msg;?></span>

    <div class="row">
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary text-center">Customer Details</h6>
            </div>
            
            <div class="card-body">
                <form class="form-horizontal" action="" method="POST" enctype="multipart/form-data">
                    
                    <!-- Customer Details -->
                    <h5 class="text-primary">Customer Details</h5>
                    <div class="form-group row">
                        <label class="control-label col-sm-2" for="customer_name">Name</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control mb-2" id="customer_name" name="customer_name" required>
                        </div>
                    </div>
                    
                    <div class="form-group row">
                        <label class="control-label col-sm-2" for="customer_email">Email</label>
                        <div class="col-sm-10">
                            <input type="email" class="form-control mb-2" id="customer_email" name="customer_email" >
                        </div>
                    </div>

                    <div class="form-group row">
                        <label class="control-label col-sm-2" for="customer_phone">Phone Number</label>
                        <div class="col-sm-10">
                            <input type="tel" class="form-control mb-2" id="customer_phone" name="customer_phone" required>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label class="control-label col-sm-2" for="customer_address">Address</label>
                        <div class="col-sm-10">
                            <textarea class="form-control mb-2" id="customer_address" name="customer_address" required></textarea>
                        </div>
                    </div>

                    <hr>

                    <!-- Optical Details -->
                  

                    <button class="btn btn-block btn-primary" type="submit" name="btn">Submit</button>
                </form>
            </div>
        </div>
    </div>
</div>



<div class="container-fluid">
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Customers</h6>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <div id="dataTable_wrapper" class="dataTables_wrapper dt-bootstrap4">
                <?php
                $query = mysqli_query($connect, "SELECT *  
                FROM customers
               
                ;
                
                    ");

               
                ?>
                <span class="text-danger"><?php echo $msg;?></span>
                <div class="row">
                        <div class="col-sm-12">
                            <table class="table table-bordered dataTable" id="dataTable" width="100%" cellspacing="0" role="grid" aria-describedby="dataTable_info">
                                <thead>
                                    <tr>
                                    <th>#</th>
                                <th>Customer Name</th>
                                <th>Customer Email</th>
                                <th>Customer Phone</th>
                                <th>Customer Address</th>
                                <th>Added Date</th>
                                
                                    </tr>
                                </thead>
                                <tbody>
                                <?php
                            if (mysqli_num_rows($query) > 0) {
                                $i==0;
                                while ($row = mysqli_fetch_assoc($query)) {
                                    $i++
                                    ?>
                                            <tr id="table_row">
                                            <td><?php echo $i;?></td>
                                        <td><?php echo $row['customer_name'] ?></td>
                                        <td><?php echo $row['customer_email'] ?></td>
                                        <td><?php echo $row['customer_phone'] ?></td>
                                        <td><?php echo $row['customer_address'] ?></td>
                                        <td><?php echo $row['create_date'] ?></td>
                                        

                                            </tr>
                                    <?php
                                        }
                                    }
                                    ?>

                                </tbody>
                            </table>
                        </div>
                    </div>
<?php
if (isset($act) && $act == "deliver") {
    
    $ins = mysqli_query($connect, "UPDATE booking SET status='2' WHERE id='$id'");
    
			if($ins)
			{
		 ?>
	<script language="javascript">
		alert("Optical Delivered");
		window.location.href="viewBiddings.php";
		 </script>
		 <?php
			}
	
	else
	{
	$msg="Error!";
	}
}
?> 

                </div>
                <div class="my-2"></div>
            </div>
        </div>
    </div>
    <?php
    include('includes/footer.php');
    include('includes/scripts.php');
    ?>