<?php
session_start();
include("dbconnect.php");
$username = $_SESSION['username'];

// Handle AJAX request to update stock
if (isset($_POST['update_stock'])) {
    $stock_id = $_POST['stock_id'];
    $new_stock = intval($_POST['new_stock']);

    $update_query = mysqli_query($connect, "UPDATE stock SET stock_count = '$new_stock' WHERE stock_id = '$stock_id'");
    if ($update_query) {
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false, 'error' => mysqli_error($connect)]);
    }
    exit();
}

// Fetch customer details
$id = isset($_REQUEST['id']) ? $_REQUEST['id'] : null;
if ($id) {
    $mq11 = mysqli_query($connect, "SELECT * FROM customers WHERE id='$id'");
    $mr11 = mysqli_fetch_array($mq11);
    $customer_name = $mr11['customer_name'];
    $customer_email = $mr11['customer_email'];
    $customer_phone = $mr11['customer_phone'];
    $customer_address = $mr11['customer_address'];
}

// Fetch stock data
$query = "SELECT * FROM stock";
$result = mysqli_query($connect, $query);

$rdate = date("d-m-Y");
$msg = "";

// Handle form submission
if (isset($_POST['btn'])) {
    // Get form data
    $brand = $_POST['brand'];
    $power_category = $_POST['power_category'];
    $fvalue = $_POST['fvalue'];
    $tvalue = $_POST['tvalue'];
    $usage = $_POST['usage'];
    $oprice = floatval($_POST['oprice']);
    $qty = intval($_POST['qty']);
    $fprice = $qty * $oprice;

    // File upload
    $uploadDir = "uploads/";
    $file = "";
    if (isset($_FILES["file"]) && $_FILES["file"]["error"] == 0) {
        $file = $uploadDir . basename($_FILES["file"]["name"]);
        if (!move_uploaded_file($_FILES["file"]["tmp_name"], $file)) {
            $msg = "File upload failed";
        }
    }

    // Get stock_id from stock table
    $stock_query = mysqli_query($connect, "SELECT stock_id FROM stock 
        WHERE power_value_from = '$fvalue' 
        AND power_value_to = '$tvalue' 
        AND power_category = '$power_category' 
        AND usuage_type = '$usage'");

    $stock_row = mysqli_fetch_array($stock_query);
    $stock_id = $stock_row['stock_id'] ?? null;

    if (!$stock_id) {
        $msg = "No matching stock found for the selected parameters";
    } else {
        // Get next ID for opticals_book
        $mq = mysqli_query($connect, "SELECT MAX(id) FROM opticals_book");
        $mr = mysqli_fetch_array($mq);
        $id = $mr['MAX(id)'] + 1;

        // Insert into opticals_book with stock_id
        $ins = mysqli_query($connect, "INSERT INTO opticals_book 
            (id, stock_id, customer_name, customer_email, customer_phone, customer_address, brand, power_category, 
            fvalue, tvalue, ousage, ofile, create_date, oprice, qty, fprice) 
            VALUES ('$id', '$stock_id', '$customer_name', '$customer_email', '$customer_phone', '$customer_address', 
            '$brand', '$power_category', '$fvalue', '$tvalue', '$usage', '$file', '$rdate', '$oprice', '$qty', '$fprice')");

        if ($ins) {
            // Update stock
            $update_stock = mysqli_query($connect, "UPDATE stock 
                SET stock_count = stock_count - $qty 
                WHERE stock_id = '$stock_id'");

            if ($update_stock) {
                // Successful submission
                echo '<script>alert("Optical Added"); window.location.href = "createop.php";</script>';
                exit(); // Ensure no further output
            } else {
                $msg = "Stock update failed: " . mysqli_error($connect);
            }
        } else {
            $msg = "Insert failed: " . mysqli_error($connect);
        }
    }
}

include('includes/header.php');
include('includes/navbar.php');
?>

<!-- Begin Page Content -->
<div class="container mt-4">
    <h2 class="text-center">Optical Stock Information</h2>

    <table class="table table-bordered" id="stockTable">
        <thead class="table-dark">
            <tr>
                <th>Stock ID</th>
                <th>Power Range</th>
                <th>Power Category</th>
                <th>Usage Type</th>
                <th>Available Stock</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($row = mysqli_fetch_assoc($result)) { ?>
                <tr>
                    <td><?php echo $row['stock_id']; ?></td>
                    <td><?php echo $row['power_value_to']; ?></td>
                    <td><?php echo $row['power_category']; ?></td>
                    <td><?php echo $row['usuage_type']; ?></td>
                    <td class="editable <?php echo $row['stock_count'] == 0 ? 'text-danger' : ''; ?>"
                        data-stock-id="<?php echo $row['stock_id']; ?>">
                        <?php echo $row['stock_count']; ?>
                    </td>
                </tr>
            <?php } ?>
        </tbody>
    </table>
</div>

<div class="container-fluid">
    <h1 class="h3 mb-4 text-gray-800 text-uppercase">Insert Optical</h1>
    <span class="text-danger"><?php echo $msg; ?></span>

    <div class="row">
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary text-center">Customer & Optical Details</h6>
            </div>

            <div class="card-body">
                <form class="form-horizontal" action="" method="POST" enctype="multipart/form-data">
                    <!-- Optical Details -->
                    <h5 class="text-primary">Optical Details</h5>
                    <div class="form-group row">
                        <label class="control-label col-sm-2" for="brand">Optical Brand</label>
                        <div class="col-sm-10">
                            <select class="form-control mb-2" id="brand" name="brand" required>
                                <option value="Ray-Ban">Ray-Ban</option>
                                <option value="Oakley">Oakley</option>
                                <option value="Persol">Persol</option>
                                <option value="Titan">Titan</option>
                                <option value="Other">Other</option>
                            </select>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label class="control-label col-sm-2" for="power_category">Power Category</label>
                        <div class="col-sm-10">
                            <select class="form-control mb-2" id="power_category" name="power_category" required>
                                <option value="spherical">Spherical</option>
                                <option value="cylinder">Cylinder</option>
                                <option value="radius">Radius</option>
                            </select>
                        </div>
                    </div>



                    <!-- <div class="form-group row">
                        <label class="control-label col-sm-2" for="fvalue">Power Value from</label>
                        <div class="col-sm-10">
                            <select class="form-control mb-2" id="fvalue" name="fvalue" required>
                                <?php for ($i = -0.25; $i <= 5.00; $i += 0.25) { ?>
                                    <option value="<?php echo $i; ?>"><?php echo $i; ?></option>
                                <?php } ?>
                            </select>
                        </div>
                    </div> -->
                    <div class="form-group row" style="display: none;">
                        <label class="control-label col-sm-2" for="fvalue">Power Value from</label>
                        <div class="col-sm-10">
                            <select class="form-control mb-2" id="fvalue" name="fvalue" required>
                                <option value="0" selected>0</option>
                            </select>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label class="control-label col-sm-2" for="tvalue">Power Value</label>
                        <div class="col-sm-10">
                            <select class="form-control mb-2" id="tvalue" name="tvalue" required>
                                <?php for ($i = -0.25; $i <= 5.00; $i += 0.25) { ?>
                                    <option value="<?php echo $i; ?>"><?php echo $i; ?></option>
                                <?php } ?>
                            </select>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label class="control-label col-sm-2" for="usage">Usage Type</label>
                        <div class="col-sm-10">
                            <select class="form-control mb-2" id="usage" name="usage" required>
                                <option value="normal-life">Normal Life</option>
                                <option value="single-vision">Single Vision</option>
                                <option value="bifocal">Bifocal</option>
                                <option value="progressive">Progressive</option>
                                <option value="reading-glass">Reading Glass</option>
                                <option value="blue-light-protection">Blue Light Protection</option>
                            </select>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label class="control-label col-sm-2" for="file">Image</label>
                        <div class="col-sm-10">
                            <input type="file" class="form-control mb-2" name="file">
                        </div>
                    </div>

                    <div class="form-group row">
                        <label class="control-label col-sm-2" for="oprice">Optical Price</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control mb-2" name="oprice" required>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label class="control-label col-sm-2" for="qty">Quantity</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control mb-2" name="qty" required>
                        </div>
                    </div>

                    <button class="btn btn-block btn-primary" type="submit" name="btn">Submit</button>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
    // Make table cells editable
    document.addEventListener('DOMContentLoaded', function () {
        const editableCells = document.querySelectorAll('.editable');

        editableCells.forEach(cell => {
            cell.addEventListener('click', function () {
                const currentValue = this.innerText;
                const stockId = this.getAttribute('data-stock-id');

                // Create input field
                const input = document.createElement('input');
                input.type = 'number';
                input.value = currentValue;
                input.style.width = '100%';

                // Replace cell content with input
                this.innerHTML = '';
                this.appendChild(input);
                input.focus();

                // Handle input change
                input.addEventListener('blur', function () {
                    const newValue = this.value;
                    cell.innerText = newValue;

                    // Send AJAX request to update database
                    const xhr = new XMLHttpRequest();
                    xhr.open('POST', '', true);
                    xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

                    xhr.onload = function () {
                        const response = JSON.parse(xhr.responseText);
                        if (response.success) {
                            alert('Stock updated successfully');
                        } else {
                            alert('Failed to update stock: ' + response.error);
                            cell.innerText = currentValue; // Revert on failure
                        }
                    };

                    xhr.send('update_stock=true&stock_id=' + stockId + '&new_stock=' + newValue);
                });

                // Handle Enter key
                input.addEventListener('keypress', function (e) {
                    if (e.key === 'Enter') {
                        this.blur();
                    }
                });
            });
        });
    });

    function checkStock() {
        return true; // Placeholder; add stock check logic later if needed
    }

    function updateStock() {
        // Placeholder; add stock update logic later if needed
    }
</script>

<?php
include('includes/footer.php');
include('includes/scripts.php');
?>